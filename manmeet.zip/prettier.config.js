module.exports = {
    plugins: [require('prettier-plugin-tailwindcss')],
  }